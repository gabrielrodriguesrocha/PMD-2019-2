for i in 10 20 30 40 50 60 70 80 100 120; do
	sudo docker exec db /opt/couchbase/bin/couchbase-cli bucket-create -c localhost -u Administrator -p 123456 --bucket ycsb-workload-a --bucket-replica 3 --bucket-ramsize 256 --bucket-type couchbase
	sleep 15
	sh setup_d.sh
	mkdir -p ./results/4-nodes/6-clients/couchbase2/workloadd_couchbase_custom && ./bin/ycsb run -s couchbase2 -P workloads/workloadd_couchbase_custom -threads $i -p statsexportfile=./results/4-nodes/6-clients/couchbase2/workloadd_couchbase_custom/result-$i.csv -p exportfile=./results/4-nodes/6-clients/couchbase2/workloadd_couchbase_custom/result-$i.txt
	sudo docker exec db /opt/couchbase/bin/couchbase-cli bucket-delete -c localhost -u Administrator -p 123456 --bucket ycsb-workload-a
	sleep 15
done
